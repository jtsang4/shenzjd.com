self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4d61947c6ec8c16906e01337f0ae886f",
    "url": "/shenzjd/watermark/index.html"
  },
  {
    "revision": "04c34988dcb22ffa6b46",
    "url": "/shenzjd/watermark/static/css/main.0853bf32.chunk.css"
  },
  {
    "revision": "b6aafa07ca16cd706e06",
    "url": "/shenzjd/watermark/static/js/2.2752fb64.chunk.js"
  },
  {
    "revision": "04c34988dcb22ffa6b46",
    "url": "/shenzjd/watermark/static/js/main.753e17ad.chunk.js"
  },
  {
    "revision": "edd9d841f205c5de2d85",
    "url": "/shenzjd/watermark/static/js/runtime~main.f2123258.js"
  }
]);